﻿using System;
using System.Linq;
using System.Text;

namespace _04.Telephony
{
    interface IBrowseable
    {
        string Browse(string website);
    }
}

namespace _04.Telephony
{
    interface ICallable
    {
        string Call(string phone);
    }
}
 
 
namespace _04.Telephony
{
    public class Smartphone : ICallable, IBrowseable
    {
        private string model;

        public Smartphone(string model)
        {
            this.model = model;
        }

        public string Browse(string website)
        {

            bool hasDigit = website.Any(char.IsDigit);
            if (hasDigit)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("Invalid URL!");
                return sb.ToString();
            }
            else
            {
                StringBuilder sb = new StringBuilder();
                sb.Append($"Browsing: {website}!");
                return sb.ToString();
            }
        }

        public string Call(string phone)
        {
            bool hasCharacter = phone.Any(char.IsLetter);
            if (hasCharacter)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("Invalid number!");
                return sb.ToString();
            }
            else
            {
                StringBuilder sb = new StringBuilder();
                sb.Append($"Calling... {phone}");
                return sb.ToString();
            }
        }
    }
}

  
namespace _04.Telephony
{
    class Startup
    {
        static void Main()
        {
            Smartphone smartphone = new Smartphone("Nokia");
            string[] phones = Console.ReadLine().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var phone in phones)
            {
                Console.WriteLine(smartphone.Call(phone));
            }
            string[] websites = Console.ReadLine().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var website in websites)
            {
                Console.WriteLine(smartphone.Browse(website));
            }
        }
    }
}