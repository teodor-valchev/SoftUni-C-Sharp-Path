﻿using System;

namespace CustomStack
{
    public class StartUp 
    {
        static void Main(string[] args)
        {
            StackOfStrings stack = new StackOfStrings();
            stack.Push("sda");
            stack.Push("sda");
            stack.Push("sda");
            stack.Push("sda");
            Console.WriteLine(stack.IsEmpty());
            stack.Pop();
            stack.Pop();
            stack.Pop();
            stack.Pop();
            Console.WriteLine(stack.IsEmpty());

        }
    }
}
