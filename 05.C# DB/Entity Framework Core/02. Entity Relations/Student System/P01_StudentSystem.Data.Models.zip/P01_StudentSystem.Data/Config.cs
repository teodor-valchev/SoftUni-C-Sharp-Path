﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data
{
    public class Config
    {
        public const string ConnectionString = @"SERVER=DESKTOP-V26OTU5\SQLEXPRESS;Database=StudentSystem;Integrated Security=True";
    }
}
