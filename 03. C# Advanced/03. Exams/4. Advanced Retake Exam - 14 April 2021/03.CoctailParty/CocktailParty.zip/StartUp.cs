﻿namespace CocktailParty
{
    using System;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            //Initialize Cocktail
            Cocktail cocktail = new Cocktail("Pina Colada", 3, 10);

            //Initialize Ingredient
            Ingredient rum = new Ingredient("Rum", 2, 3);

            //Print rum
            Console.WriteLine(rum.ToString());

            cocktail.Add(rum);

            //Remove rum
            Console.WriteLine(cocktail.Remove("Rum"));

            Ingredient vodka = new Ingredient("Vodka", 2, 5);
            Ingredient milk = new Ingredient("Milk", 3, 5);

            //Add ingredients
            cocktail.Add(vodka);
            cocktail.Add(milk);

            //GetMostAlcoholicIngredient
            Console.WriteLine(cocktail.GetMostAlcoholicIngredient());

            Console.WriteLine(cocktail.CurrentAlcoholLevel);
            //Ingredient: Vodka
            //Quantity: 5
            //Alcohol: 2
            Console.WriteLine(cocktail.Report());

        }
    }
}
